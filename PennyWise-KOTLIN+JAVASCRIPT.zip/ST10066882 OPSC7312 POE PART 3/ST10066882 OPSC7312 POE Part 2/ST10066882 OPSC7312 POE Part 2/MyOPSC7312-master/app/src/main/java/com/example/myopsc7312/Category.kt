package com.example.myopsc7312

data class Category(
    val categoryId: String,
    val name: String,
    val monthPaid: String,
    val amount: Double
)
