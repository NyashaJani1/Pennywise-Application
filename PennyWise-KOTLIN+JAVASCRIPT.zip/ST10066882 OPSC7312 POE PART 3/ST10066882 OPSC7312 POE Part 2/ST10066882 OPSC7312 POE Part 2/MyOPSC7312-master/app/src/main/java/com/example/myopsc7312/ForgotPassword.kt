package com.example.myopsc7312

class ForgotPassword {

}